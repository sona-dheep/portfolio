/* ═══════════════════════════════════════════════════════════
   BEHAVIOUR
   Renders content from data.js, then wires up the tabs,
   mobile menu, scroll-spy nav and reveal-on-scroll.
   You shouldn't need to edit this file to change content.
   ═══════════════════════════════════════════════════════════ */

(function () {
  "use strict";

  var reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ── footer year ─────────────────────────────────────── */
  document.getElementById("year").textContent = new Date().getFullYear();

  /* ── timeline ────────────────────────────────────────── */
  document.getElementById("timeline").innerHTML = TIMELINE.map(function (t) {
    return (
      '<li>' +
        '<span class="dot"></span>' +
        '<p class="period">' + t.period + '</p>' +
        '<p class="role">' + t.role + '</p>' +
        '<p class="place">' + t.place + '</p>' +
      '</li>'
    );
  }).join("");

  /* ── quotes ──────────────────────────────────────────── */
  document.getElementById("quotes").innerHTML = QUOTES.map(function (q) {
    return (
      '<figure class="quote">' +
        '<blockquote>' + q.quote + '</blockquote>' +
        '<figcaption>' +
          '<span class="avatar" aria-hidden="true">' + q.initials + '</span>' +
          '<span class="who">' + q.name + '<span>' + q.role + '</span></span>' +
        '</figcaption>' +
      '</figure>'
    );
  }).join("");

  /* ── methods ─────────────────────────────────────────── */
  document.getElementById("methods").innerHTML = METHODS.map(function (m) {
    return '<div class="method"><b>' + m.name + '</b><span>' + m.note + '</span></div>';
  }).join("");

  /* ── projects ────────────────────────────────────────── */
  document.getElementById("projects").innerHTML = PROJECTS.map(function (p, i) {
    var coverLinks = p.links.length
      ? '<div class="cover-links">' + p.links.map(function (l) {
          return '<a href="' + l.href + '" target="_blank" rel="noopener">' + l.label + '</a>';
        }).join("") + '</div>'
      : "";

    var tabButtons = p.tabs.map(function (t, n) {
      return '<button role="tab" id="tab-' + i + '-' + n + '" aria-controls="panel-' + i + '-' + n + '"' +
             ' aria-selected="' + (n === 0) + '" data-card="' + i + '" data-tab="' + n + '">' +
             t.label + '</button>';
    }).join("");

    var panels = p.tabs.map(function (t, n) {
      return '<div class="panel" role="tabpanel" id="panel-' + i + '-' + n + '"' +
             ' aria-labelledby="tab-' + i + '-' + n + '"' + (n === 0 ? "" : " hidden") + '>' +
             t.html + '</div>';
    }).join("");

    return (
      '<article class="card reveal" data-card="' + i + '">' +
        '<div class="cover" style="background:' + p.coverBg + '">' +
          '<img src="' + p.img + '" alt="' + p.title.replace(/&amp;/g, "and") + '" loading="lazy">' +
          '<span class="cover-veil"></span>' +
          coverLinks +
          '<div class="cover-text">' +
            '<div class="pills">' + p.pills.map(function (t) { return "<span>" + t + "</span>"; }).join("") + '</div>' +
            '<h3>' + p.title + '</h3>' +
            '<p>' + p.subtitle + '</p>' +
          '</div>' +
        '</div>' +
        '<div class="tabs" role="tablist" aria-label="' + p.title.replace(/&amp;/g, "and") + ' sections">' + tabButtons + '</div>' +
        panels +
      '</article>'
    );
  }).join("");

  /* ── tabs ────────────────────────────────────────────── */
  document.getElementById("projects").addEventListener("click", function (e) {
    var btn = e.target.closest('[role="tab"]');
    if (!btn) return;
    switchTab(btn);
  });

  /* arrow-key support inside a tablist */
  document.getElementById("projects").addEventListener("keydown", function (e) {
    var btn = e.target.closest('[role="tab"]');
    if (!btn) return;
    if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
    e.preventDefault();
    var all = Array.prototype.slice.call(btn.parentNode.children);
    var i = all.indexOf(btn) + (e.key === "ArrowRight" ? 1 : -1);
    var target = all[(i + all.length) % all.length];
    target.focus();
    switchTab(target);
  });

  function switchTab(btn) {
    var card = btn.dataset.card;
    var tab = btn.dataset.tab;

    btn.parentNode.querySelectorAll('[role="tab"]').forEach(function (b) {
      b.setAttribute("aria-selected", b === btn);
    });
    document.querySelectorAll('[id^="panel-' + card + '-"]').forEach(function (panel) {
      panel.hidden = panel.id !== "panel-" + card + "-" + tab;
    });
  }

  /* ── mobile menu ─────────────────────────────────────── */
  var burger = document.getElementById("burger");
  var navLinks = document.getElementById("navLinks");

  burger.addEventListener("click", function () {
    var open = navLinks.classList.toggle("open");
    burger.setAttribute("aria-expanded", open);
    burger.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  });

  navLinks.addEventListener("click", function (e) {
    if (e.target.tagName === "A") {
      navLinks.classList.remove("open");
      burger.setAttribute("aria-expanded", "false");
    }
  });

  /* ── scroll-spy ──────────────────────────────────────── */
  var sections = ["about", "work", "process", "contact"];
  var spy = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (!entry.isIntersecting) return;
      navLinks.querySelectorAll("a").forEach(function (a) {
        a.classList.toggle("active", a.getAttribute("href") === "#" + entry.target.id);
      });
    });
  }, { rootMargin: "-45% 0px -50% 0px" });

  sections.forEach(function (id) {
    var el = document.getElementById(id);
    if (el) spy.observe(el);
  });

  /* ── reveal on scroll ────────────────────────────────── */
  var revealables = document.querySelectorAll(".reveal");

  if (reduced) {
    revealables.forEach(function (el) { el.classList.add("in"); });
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("in");
          io.unobserve(entry.target);
        }
      });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });

    revealables.forEach(function (el) { io.observe(el); });

    /* hero is above the fold — reveal it immediately */
    requestAnimationFrame(function () {
      document.querySelectorAll(".hero .reveal").forEach(function (el) { el.classList.add("in"); });
    });
  }
})();
